#pragma once

#include <QWidget>
#include "ui_itemwidget.h"
#include "taskdata.h"

class ItemWidget : public QWidget
{
    Q_OBJECT

public:
    ItemWidget(QWidget *parent = nullptr);
    ~ItemWidget();

    void     setData(const TaskData& data);
    TaskData getData();

signals:
    void clickedView();
    void clickedDelete();
    void clickedOpendir();

private:
    Ui::ItemWidgetClass ui;

    TaskData task_;
};
